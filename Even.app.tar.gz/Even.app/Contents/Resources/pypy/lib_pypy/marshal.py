# Note that PyPy contains also a built-in module 'marshal' which will
# hide this one if compiled in.

from _marshal import __doc__
from _marshal import *
